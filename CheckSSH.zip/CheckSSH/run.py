import paramiko

def check_ssh_connection(ip_address, username, password, success_file):
    # Tạo một máy khách SSH mới
    ssh = paramiko.SSHClient()

    # Tự động thêm khóa máy chủ của máy chủ
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    try:
        # Kết nối với máy chủ
        ssh.connect(ip_address, username=username, password=password)
        print("  Kết nối SSH thành công cho {}".format(ip_address))
        with open(success_file, "a") as f:
            f.write(ip_address + "\n")
    except Exception as e:
        print("  Lỗi kết nối với {}: {}".format(ip_address, e))
    finally:
        # Đóng kết nối SSH
        ssh.close()

# Thông tin đăng nhập SSH
username = "root"
password = "hqdata@9999"

# Đọc danh sách địa chỉ IP từ một tệp
with open("ip.txt", "r") as f:
    ip_list = f.read().splitlines()

# Tên tệp để lưu trữ các kết nối SSH thành công
success_file = "success.txt"

# Kiểm tra kết nối SSH cho từng địa chỉ IP
for ip in ip_list:
    check_ssh_connection(ip, username, password, success_file)
